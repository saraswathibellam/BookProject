package com.besant.bookapplication;

import com.besant.authordetails.*;
import com.besant.bookdetails.*;
import java.util.Scanner;

public class BookApplication {

	public static void main(String[] args) {
		System.out.println("1) Add Author");
		System.out.println("2) Remove Author");
		System.out.println("3) Update Author");
		System.out.println("4) Add Book");
		System.out.println("5) Rename Book");
		System.out.println("6) Update Book");
		System.out.println("7) Remove Book ");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Choice");

		int choice = -1;

		while (choice != 0) {

			choice = sc.nextInt();

			switch (choice) {
			case 1:
				AddAuthor.main(null);
				break;
			case 2:
				RemoveAuthor.main(null);

				break;
			case 3:

				UpdateAuthor.main(null);
				break;
			case 4:
				AddBook.main(null);

				break;
			case 5:
				RenameBook.main(null);

				break;
			case 6:
				UpdateBook.main(null);

				break;
			case 7:
				RemoveBook.main(null);

				break;
			case 0:
				System.out.println("Exit");
				break;
			default:
				System.out.println("Invalid Books");
			}
			;

		}
		sc.close();
	}
}
