package com.besant.bookdetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.cj.jdbc.JdbcConnection;

public abstract class BookList {
abstract void bookList();
public static void main(String[] args) {
//	Scanner sc = new Scanner(System.in);
//
//	System.out.println("Enter Book ID:");
//	int b_id = sc.nextInt();
//	sc.nextLine();
//
//	 
//	 
//	System.out.println("Enter Book Name:");
//	String b_name = sc.nextLine();
//
//	System.out.println("Enter Book Price:");
//	int b_price = sc.nextInt();
//
//	System.out.println("Enter Author ID:");
//	int c_id = sc.nextInt();
	
	
	String url="jdbc:mysql://Localhost:3306/bookdept";
	String username="root";
	String password="root";
	
	String query="Select b.b_id,b.b_name,b.b_price from book b join author a on a_id=b_id";
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con =DriverManager.getConnection(url, username, password);
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(query);
		
		while(rs.next()) {
			System.out.println(rs.getInt("b_id"));
			System.out.println(rs.getInt("b_name"));
			System.out.println(rs.getInt("b_price"));
			System.out.println(rs.getInt("c_id"));
		}
	} catch (ClassNotFoundException | SQLException e) {
		
		e.printStackTrace();
	}
	
	
}
}
