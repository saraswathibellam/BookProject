package com.besant.bookdetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public abstract class RemoveBook {
	public abstract void removeBook();
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
//	System.out.println("Enter Book Name:");
//	String b_name = sc.nextLine();
//		System.out.println("Enter Book Price:");
//		int b_price = sc.nextInt();

		System.out.println("Enter Book ID:");
		int a_id = sc.nextInt();

//	System.out.println("Enter Author ID:");
//	int c_id = sc.nextInt();

		String url = "jdbc:mysql://Localhost:3306/bookdept";
		String username = "root";
		String password = "root";

		String query = "Delete from book  where b_id=?";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username, password);
			PreparedStatement ps = con.prepareStatement(query);
//		ps.setInt(1, b_price);
			ps.setInt(1, a_id);
//		ps.setInt(1, b_name);
//		ps.setInt(2, c_id);

			int res1 = ps.executeUpdate();
			if (res1 > 0) {
				System.out.println("Book Removed Successfully!");
			} else {
				System.out.println("Book Removed Failed!");
			}

		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}
	}
}
