package com.besant.bookdetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public abstract class AddBook {
	public abstract void addBook();
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Book ID:");
		int b_id = sc.nextInt();
		sc.nextLine();

		System.out.println("Enter Book Name:");
		String b_name = sc.nextLine();

		System.out.println("Enter Book Price:");
		int b_price = sc.nextInt();

		System.out.println("Enter Author ID:");
		int c_id = sc.nextInt();

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			String url = "jdbc:mysql://localhost:3306/bookdept";
			String username = "root";
			String password = "root";
			String query = "INSERT INTO book (b_id, b_name, b_price, c_id) VALUES (?, ?, ?, ?)";

			Connection con = DriverManager.getConnection(url, username, password);
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, b_id);
			ps.setString(2, b_name);
			ps.setDouble(3, b_price);
			ps.setInt(4, c_id);

			int res1 = ps.executeUpdate();
			if (res1 > 0) {
				System.out.println("Book Added Successfully!");
			} else {
				System.out.println("Book Insert Failed!");
			}

			ps.close();
			con.close();
			sc.close();

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
}
