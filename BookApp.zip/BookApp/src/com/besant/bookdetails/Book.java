package com.besant.bookdetails;

public class Book {
	int b_ID;
	String b_NAME;
	double b_PRICE;
	int a_ID;

	public Book(int b_ID, String b_NAME, int b_PRICE, int a_ID) {
		super();
		this.b_ID = b_ID;
		this.b_NAME = b_NAME;
		this.b_PRICE = b_PRICE;
		this.a_ID = a_ID;
	}

	@Override
	public String toString() {
		return "Book [b_ID=" + b_ID + ", b_NAME=" + b_NAME + ", b_PRICE=" + b_PRICE + ", a_ID=" + a_ID + "]";
	}

}
