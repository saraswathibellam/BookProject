package com.besant.jdbcConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBC_Con {
	static String url = "jdbc:mysql://Localhost:3306/bookdept";
	static String username = "root";
	static String password = "root";

	public static Connection getConnection() {
		Connection con = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con1 = DriverManager.getConnection(url, username, password);

			System.out.println("Driver Class Loaded");

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();

		}

		return con;
	}

}
