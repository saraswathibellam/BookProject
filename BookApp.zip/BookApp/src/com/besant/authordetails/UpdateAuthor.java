package com.besant.authordetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public  abstract class UpdateAuthor {
	public abstract void updateAuthor();
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);

	System.out.println("Enter Author ID:");
	int a_id = sc.nextInt();
	sc.nextLine();

//	System.out.println("Enter Author Name:");
//	String a_name = sc.nextLine();

	System.out.println("Enter Author Address:");
	String a_address = sc.nextLine();

	String url = "jdbc:mysql://Localhost:3306/bookdept";
	String username = "root";
	String password = "root";
	String query = "Update Author set a_id=? where a_address=?";

	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, password);
		PreparedStatement ps = con.prepareStatement(query);
		ps.setInt(1, a_id);
		//ps.setString(2, a_name);
		ps.setString(2, a_address);

		int res = ps.executeUpdate();
		if (res > 0) {
			System.out.println(" Author Update Successfully!");
		} else {
			System.out.println("Author Update Failed!");
		}

	} catch (ClassNotFoundException e) {

		e.printStackTrace();
	} catch (SQLException e) {

		e.printStackTrace();
	}
}
}
