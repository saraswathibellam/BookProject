package com.besant.authordetails;

public class Author {
	int a_ID;
	String a_NAME;
	String a_ADDRESS;

	public Author(int a_ID, String a_NAME, String a_ADDRESS) {
		super();
		this.a_ID = a_ID;
		this.a_NAME = a_NAME;
		this.a_ADDRESS = a_ADDRESS;
	}

	@Override
	public String toString() {
		return "Author [a_ID=" + a_ID + ", a_NAME=" + a_NAME + ", a_ADDRESS=" + a_ADDRESS + "]";
	}

}
