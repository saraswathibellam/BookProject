
public class LoopWhile extends LoopingStatements {

	public static void main(String[] args) {
		// while loop
		int i=0;
		while(i<=5){
			System.out.println("The num is: "+i);
			i++;
		}

	}

}
