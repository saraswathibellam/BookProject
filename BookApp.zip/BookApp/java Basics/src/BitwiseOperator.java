
public class BitwiseOperator {

	public static void main(String[] args) {
		int a=2, b=6;
		System.out.println(a&b); //0010 0110 =0010 =2
		System.out.println(a|b); //0010 0110 =0110 =6
		
	}

}
