
public class ControlSwith {

	public static void main(String[] args) {
		//switch case
		int a=3;
		switch(a) {
		case 1:
			System.out.println("case1");
			break;
		case 2:
			System.out.println("case 2");
			break;
		case 3:
			System.out.println("case 3");
		    break;
		case 4:
			System.out.println("case 4");
			break;
		case 5:
			System.out.println("case 5");
			break;
		
		}
		System.out.println("no such case is available");
		
	}

}
