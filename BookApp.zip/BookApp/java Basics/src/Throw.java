
public class Throw {
	static void check(int a) {

		if (a < 18) {
			throw new ArithmeticException("not eligile");
		}

		else

		{
			System.out.println("eligible");
		}

	}

	public static void main(String[] args) {
		check(13);
		System.out.println("hello");
	}
}
