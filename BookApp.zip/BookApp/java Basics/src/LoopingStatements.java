
public class LoopingStatements {

	public static void main(String[] args) {
		// 

	}

}
