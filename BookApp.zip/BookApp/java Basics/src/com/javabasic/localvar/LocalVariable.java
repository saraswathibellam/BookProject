package com.javabasic.localvar;

public class LocalVariable {
public void variable() {
	String a ="Saru";
	System.out.println("My name is : "+a);
	
}//end of the De-allocates memory

public static void main(String[] args) {
	LocalVariable obj =new LocalVariable();
	obj.variable();//method calling -memory allocates
}
}
