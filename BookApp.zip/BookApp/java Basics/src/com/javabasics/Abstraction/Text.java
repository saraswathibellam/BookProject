package com.javabasics.Abstraction;
interface  Printable{
	void Print();
}
interface Showable{
	void Show();
}
public  class Text implements Printable,Showable{
	public void print() {
		System.out.println("Print");
	}
	public void show() {
		System.out.println("Show");
	}
	public static void main(String[] args) {
		Text t = new Text();
		t.print();
		t.show();

	}

}


