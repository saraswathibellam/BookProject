package com.javabasics.Abstraction;

abstract class Names {

	Names(int a) {

	}

	abstract void fun();

	// Abstract methods do not specify a body
	abstract void fun1();
}

abstract class Saru extends Names
/*
 * The type Saru must implement the inherited abstract method Names.fun1()
 */
{
	

	void fun() {

	}
}

public class Person {
	public static void main(String[] args) {
		// Names n= new Names();
		// Cannot instantiate the type of obj(Names) in abstract

	}

}
