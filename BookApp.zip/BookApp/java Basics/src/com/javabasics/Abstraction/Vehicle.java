package com.javabasics.Abstraction;

abstract class Car {
	String n;

	Car(String n) {
		this.n = n;
	}

	abstract void fun();

	void fun1() {
		System.out.println(n);
	}

}

class Brakes extends Car {
	Brakes(String n) {
		super(n);

	}

	void fun() {
		System.out.println("Car should be halted");
	}

}

class Accelerator extends Car {
	Accelerator(String n) {
		super(n);
	}

	void fun() {
		System.out.println("Car is accelerated");
	}
}

class Gears extends Car {
	int c;

	Gears(String n, int c) {
		super(n);
		this.c = c;

	}

	void fun() {
		System.out.println("Car Gear should be changes " + c);
	}
}

public class Vehicle {

	public static void main(String[] args) {
		Brakes b = new Brakes("Brakes");
		b.fun();
		b.fun1();
		Accelerator a = new Accelerator("Accelerator");
		a.fun();
		a.fun1();
		Gears g = new Gears("Gears", 4);
		g.fun();
		g.fun1();
	}

}
