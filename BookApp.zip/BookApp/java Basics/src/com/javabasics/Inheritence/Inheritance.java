package com.javabasics.Inheritence;

class Trees {
	void printT() {
		System.out.println("Tree gives fruits");
	}

}

class Mango extends Trees {
	void printM() {
		System.out.println("Mangos are sweet");
	}

}

public class Inheritance {

	public static void main(String[] args) {
		Mango t = new Mango();
		t.printT();
		t.printM();

	}

}
