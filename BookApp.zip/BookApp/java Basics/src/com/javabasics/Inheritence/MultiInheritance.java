package com.javabasics.Inheritence;

class Plants {
	void printP() {
		System.out.println("This is a Plant");
	}
}

class Tree extends Plants {
	void printT() {
		System.out.println("This is a Tree");
	}
}

class Apple extends Tree {
	void printA() {
		System.out.println("This is a Apple");
	}
}

public class MultiInheritance {

	public static void main(String[] args) {
		Apple a = new Apple();
		a.printA();
		a.printT();
		a.printP();
	}

}
