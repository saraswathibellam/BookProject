package com.javabasics.Inheritence;

class PetAnimals {
	void printP() {
		System.out.println("This is from PetAnimals");
	}
}

class Dogs extends PetAnimals {
	void printD() {
		System.out.println("This is a Dog");
	}

}

class Cats extends PetAnimals {
	void printC() {
		System.out.println("This is a Cat");
	}

}

public class Hirarchicalinheritance {

	public static void main(String[] args) {
		Dogs b = new Dogs();
		Cats a = new Cats();
		b.printD();
		b.printP();
		a.printC();
		a.printP();

	}

}
