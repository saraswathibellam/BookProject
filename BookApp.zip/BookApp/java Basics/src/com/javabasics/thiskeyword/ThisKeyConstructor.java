package com.javabasics.thiskeyword;

public class ThisKeyConstructor {
	String a;

	ThisKeyConstructor() {

		System.out.println("Gd Mrng");
	}

	ThisKeyConstructor(String a) {
		this();

		System.out.println(a);
	}

	public static void main(String[] args) {
		ThisKeyConstructor c = new ThisKeyConstructor("Bangalure");

	}

}
