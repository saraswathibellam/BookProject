package com.javabasics.thiskeyword;

public class ThisKeyword {
	String n;
	

	public ThisKeyword(String n) {

		this.n = n;
	}
	void display() {
		System.out.println("this keyword is "+n);
	}


	public static void main(String[] args) {
		ThisKeyword t = new ThisKeyword("current instance class");
		t.display();
		
	}

}
