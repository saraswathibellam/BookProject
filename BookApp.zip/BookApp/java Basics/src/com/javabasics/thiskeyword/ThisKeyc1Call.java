package com.javabasics.thiskeyword;
class C{
	Thiskeyc1Call ob;

	public C(Thiskeyc1Call ob) {
		this.ob = ob;
	}
	void display() {
		System.out.println(ob.data);
	}
}

public class ThisKeyc1Call {
	int data;

	public static void main(String[] args) {
		ThisKeyc1Call c =new ThisKeyc1Call(100);
		
		
	}

}
