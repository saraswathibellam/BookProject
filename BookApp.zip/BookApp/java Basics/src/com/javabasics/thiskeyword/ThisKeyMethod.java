package com.javabasics.thiskeyword;

public class ThisKeyMethod {
	public void displaym1() {

		System.out.println("Hlo");
	}

	public void displaym2() {
		displaym1();
		System.out.println("India");
	}

	public static void main(String[] args) {
		ThisKeyMethod t = new ThisKeyMethod();
		t.displaym2();

	}

}
