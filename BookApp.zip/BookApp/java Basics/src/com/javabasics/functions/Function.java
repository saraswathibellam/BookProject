package com.javabasics.functions;

public class Function {

	public static void main(String[] args) {
		//creatimg an object
		Function obj = new Function();//initialization
		
	}

}
