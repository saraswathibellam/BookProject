package com.javabasics.functions;
import java.util.Scanner;
public class Print {
	
	static int printAdd(int a,int b) {
		System.out.println("sum is : "+(a+b));
		return a+b;
		
	}

	public static void main(String[] args) {
		//int x=2;
		//int y=7;
		System.out.println("enter the 2 num is:");
		Scanner sc = new Scanner(System.in);
		int x=sc.nextInt();
		int y=sc.nextInt();
		printAdd(x, y);
	}

}
