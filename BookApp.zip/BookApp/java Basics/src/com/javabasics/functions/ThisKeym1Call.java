package com.javabasics.functions;

public class ThisKeym1Call {
	Void m(ThisKeym1Call obj) {
		System.out.println("Hlo Guru");
	}

	void s() {
		m(this);
	}

	public static void main(String[] args) {
		ThisKeym1Call t = new ThisKeym1Call();
		t.s();
	}

}
