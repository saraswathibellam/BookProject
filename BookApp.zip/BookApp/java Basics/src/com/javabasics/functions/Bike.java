package com.javabasics.functions;

public class Bike {
	static int wheels=2;
	String color="";
	
	static void breaking() {
		System.out.println("breakes is Applied");
	}
	void mileage(int a) {
		System.out.println(a + "KMPH");
	}
	public static void main(String[] args) {
		Bike RoyalEnfield = new Bike();
		Bike R15 = new Bike();
		Bike Herohonda= new Bike();
		
		RoyalEnfield.breaking();
		R15.breaking();
		Herohonda.breaking();
		
		
		System.out.println(RoyalEnfield.wheels +"wheels");
		System.out.println(R15.wheels +"wheels");
		System.out.println(Herohonda.wheels +"wheels");
		
	RoyalEnfield.color="Black";
	R15.color="Ash";
	Herohonda.color="Red";
	
	RoyalEnfield.mileage(94);
	R15.mileage(56);
	Herohonda.mileage(68);
	
	System.out.println(RoyalEnfield.color);
	System.out.println(R15.color);
	System.out.println(Herohonda.color);
	
	}

}
