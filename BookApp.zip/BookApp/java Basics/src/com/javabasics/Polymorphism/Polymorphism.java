package com.javabasics.Polymorphism;

class Colleges {
	static void c1() {
		System.out.println("h---This is a College");
	}

	void c2() {
		System.out.println("o---This is college");
	}
}

class Student extends Colleges {
	static void c1() {
		System.out.println("h--This is student");
	}

	void c2() {
		System.out.println("o--This is student");
	}
}

public class Polymorphism {

	public static void main(String[] args) {
		// Student s= new Student();
		// Colleges s = new Colleges();
		Colleges s = new Student();
		// Colleges is a Reference type - static
		// Student is a Runtime object - dynamic/non-static
		s.c1();
		s.c2();

	}

}
