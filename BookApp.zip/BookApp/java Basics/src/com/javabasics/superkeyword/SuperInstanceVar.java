package com.javabasics.superkeyword;

class Devices {
	String n = "Lg";

	void display() {
		System.out.println(n);
	}

}

class TV extends Devices {
	String n = "Samsung";

	TV() {
		super();
		System.out.println(super.n);
		System.out.println(n);
	}
}

public class SuperInstanceVar {

	public static void main(String[] args) {
		TV t = new TV();
	}

}
