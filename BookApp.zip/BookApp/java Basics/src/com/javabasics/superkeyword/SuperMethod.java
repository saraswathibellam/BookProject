package com.javabasics.superkeyword;

class Device {

	void display() {
		System.out.println("This is a Parent Class");
	}

}

class SmartWatch extends Device {

	void display1() {
		display();
		System.out.println("This  Child Class extends from Parent Class");
	}

}

public class SuperMethod {

	public static void main(String[] args) {

		SmartWatch s = new SmartWatch();
		// s.display();
		s.display1();

	}

}
