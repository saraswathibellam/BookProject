package com.javabasics.superkeyword;

class College {
	// String a="Anna";
	College() {
		System.out.println("This is a  University");
	}
}

class Students extends College {
	String a = "BE";

	Students() {
		super();
		System.out.println("Am studying " + a + " in University");

	}

}

public class SuperConstructor {
	public static void main(String[] args) {
		Students s = new Students();
	}

}
