package com.javabasics.Final;

final class F1 {
	void f1() {
		System.out.println("hi");
	}
}

class Finals extends F1
//The type Finals cannot subclass the final class F1
{
	void f1() {

		System.out.println("hlo");
	}
}

public class FinalConstructor {
	public static void main(String[] args) {
		F f = new Final();
		f.f1();// calling

	}
}