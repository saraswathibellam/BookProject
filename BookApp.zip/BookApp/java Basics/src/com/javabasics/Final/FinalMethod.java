package com.javabasics.Final;

class F {
	final void f1() {
		System.out.println("hi");
	}
}

class Final extends F {
	void f1() // Cannot override the final method from F
	{

		System.out.println("hlo");
	}
}

public class FinalMethod {
	public static void main(String[] args) {
		F f = new Final();
		f.f1();// calling

	}

}
