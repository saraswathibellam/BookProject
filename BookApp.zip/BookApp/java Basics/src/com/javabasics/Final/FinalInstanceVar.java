package com.javabasics.Final;

public class FinalInstanceVar {
	final int a = 12;

	public static void main(String[] args) {
		FinalInstanceVar f = new FinalInstanceVar();
		f.a = 87;
		/* The final field FinalInstanceVar.a cannot be assigned */
		System.out.println(f.a);
	}
}
