package com.java.minmax;
import java.util.Scanner;
public class MinMax {
	int I;
	int S;
	public static void min(int a, int b) {
		if(a>b) {
			System.out.println(a +"is max");
		}
		else {
			System.out.println(b +"is max");
		}
	}

	public static void main(String[] args) {
		MinMax m1 = new MinMax();
		System.out.println("enter 2 num");
		Scanner sc =new Scanner(System.in);
		int c=sc.nextInt();
		int d=sc.nextInt();
		min(c,d);
		
	}
}
