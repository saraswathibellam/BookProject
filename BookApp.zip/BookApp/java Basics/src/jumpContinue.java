
public class jumpContinue extends JumpingStatements {

	public static void main(String[] args) {
		// Continue
		
				int i=0;
				for(i=0;i<=10;i++) {
					if(i==5) {
					continue;
					}
					System.out.println(i);
					
				}
				System.out.println("saru");
	}

}
	
