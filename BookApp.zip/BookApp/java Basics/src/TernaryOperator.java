
public class TernaryOperator {

	public static void main(String[] args) {
		int a=4, b=7;
		int max=(a<b)?a:b;
		int max1=(a>b)?a:b;
		System.out.println(max);
		System.out.println(max1);
	}

}
