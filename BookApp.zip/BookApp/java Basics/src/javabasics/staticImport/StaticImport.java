package javabasics.staticImport;

import static java.lang.Math.*;

public class StaticImport {
	public static void main(String[] args) {
		System.out.println("power function: " + pow(3, 4));
		System.out.println("Maximum: " + max(6, 9));
		System.out.println("Minimum: " + min(2, 5));
	}
}
