package javabasics.stringtest1;

public class StringTest {
	public static void main(String[] args) {
		String a = "Hi Nanna";
		String c = new String("aaa");
		String b = new String("AAA");
		System.out.println(a.charAt(3));
		System.out.println(a.lastIndexOf('n'));
		System.out.println(a.contains("a"));
		System.out.println(b.length());
		System.out.println(a.endsWith("a"));
		System.out.println(a.replace("i", "I"));
		System.out.println(a.toUpperCase());
		System.out.println(b.toLowerCase());
		System.out.println(c.equals(b));
		System.out.println(c.equalsIgnoreCase(b));
	}

}
