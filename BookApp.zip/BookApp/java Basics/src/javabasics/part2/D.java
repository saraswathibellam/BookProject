package javabasics.part2;

import javabasics.part1.A;

public class D {

	public static void main(String[] args) {

		A a = new A();
		a.print("saru");
		System.out.println(a.a);
	}

}
