package javabasics.part2;

import javabasics.part1.A;

public class B extends A {

	public static void main(String[] args) {

		B b = new B();
		b.print("saru");
		System.out.println(b.a);
	}

}
