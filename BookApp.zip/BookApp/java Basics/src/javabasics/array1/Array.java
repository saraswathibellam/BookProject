package javabasics.array1;

public class Array {

}
