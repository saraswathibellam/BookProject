package javabasics.exceptionhandling;

public class TryCatch1 {
	public static void main(String[] args) {
		/*
		 * Exception is not occurs but we are using try catch block how to print the
		 * statements in exception handling
		 */
		try {
			int a = 10 / 2;
			System.out.println("1");
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("2");
		} finally {
			System.out.println("is executed");
		}
		System.out.println("3");
	}
}
