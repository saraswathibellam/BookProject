package javabasics.exceptionhandling;

public class Throws {
	static int div(int a, int b) {
		int d = a / b;
		return d;
	}

	public static void main(String[] args) {
		Throws t = new Throws();
		try {
			// System.out.println(div(10, 0));
			System.out.println(t.div(10, 0));
		} catch (ArithmeticException e) {
			System.out.println(e);
		} finally {
			System.out.println(div(10, 2));
		}
	}
}
