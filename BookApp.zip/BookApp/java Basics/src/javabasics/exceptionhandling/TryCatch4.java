package javabasics.exceptionhandling;

public class TryCatch4 {
	static void check(int a) {
		try {
			if (a < 18) {
				throw new ArithmeticException("not eligile");
			} else

			{
				System.out.println("eligible");
			}

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			System.out.println("world");
		}
	}

	public static void main(String[] args) {
		check(19);
		System.out.println("hello");

	}
}
