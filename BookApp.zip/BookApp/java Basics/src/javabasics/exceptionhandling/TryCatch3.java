package javabasics.exceptionhandling;

public class TryCatch3 {
	static void check(int a) {
		try {
			if (a < 18) {
				throw new ArithmeticException("not eligile");
			} else

			{
				System.out.println("eligible");
			}

		} catch (Exception e) {
			System.out.println(e);

		}
		System.out.println("world");
	}

	public static void main(String[] args) {
		check(13);
		System.out.println("hello");

	}
}