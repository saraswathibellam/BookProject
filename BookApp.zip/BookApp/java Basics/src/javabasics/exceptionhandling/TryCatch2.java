package javabasics.exceptionhandling;

public class TryCatch2 {
	public static void main(String[] args) {
		try {
			int a = 10 / 0;
			System.out.println("1");
		} catch (NullPointerException e) {
			System.out.println(e);
			System.out.println("2");
		} finally {
			System.out.println("is executed");F
		}
		System.out.println("3");
	}
}
