package javabasics.arrays;

public class multiDArray {
	public static void main(String[] args) {
		int a[][] = { { 2, 87 }, { 3, 6 }, { 89, 32 } };
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				// System.out.println("a[" + i + "][" + j + "]=" + a[i][j]);
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	}
}
