package javabasics.arrays;

public class MultiDArray1 {
	public static void main(String[] args) {
		String a[][] = { { "2", "Pushpa" }, { "Saru", "Naga" }, { "6", "7" } };
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				// System.out.println("a[" + i + "][" + j + "]=" + a[i][j]);
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	}
}
