package javabasics.arrays;

public class Array {
	public static void main(String[] args) {
		int a[] = new int[4];
		a[0] = 4;
		a[1] = 5;
		a[2] = 6;
		a[3] = 7;
System.out.println(a[2]);
	}
}
