package javabasics.arrays;

public class Array2 {
	public static void main(String[] args) {
		String a[] = new String[3];
		a[0] = "Naga";
		a[2] = "Pushpa";
		System.out.println(a[2]);
		for (int i = 0; i < 3; i++) {
			System.out.println(a[i]);
		}
	}
}
