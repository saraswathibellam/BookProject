package javabasics.arrays;

public class Array1 {
	public static void main(String[] args) {
		int a[] = new int[5];
		a[0] = 4;
		a[1] = 5;
		a[2] = 6;
		a[3] = 7;
		for (int i = 0; i < 5; i++) {
			System.out.println(a[i]);
		}
	}
}
