package javabasics.arrays;

import java.util.Arrays;

public class OneDArray1 {
	public static void main(String[] args) {
		String a[] = { "Naga", "Saru", "Pushpa" };
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		Arrays.sort(a);
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
	}
}
