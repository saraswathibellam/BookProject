package javabasics.part1;

public class A {
	public int a = 10;

	public void print(String s) {

		System.out.println(s);
	}

	public static void main(String[] args) {
		


	}

}
