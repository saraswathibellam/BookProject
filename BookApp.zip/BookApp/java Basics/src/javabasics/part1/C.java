package javabasics.part1;

public class C {

	public static void main(String[] args) {
		A a = new A();
		a.print("saru");
		System.out.println(a.a);

	}

}
