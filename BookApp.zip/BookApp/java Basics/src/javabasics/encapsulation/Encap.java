package javabasics.encapsulation;

public class Encap {
	public static void main(String[] args) {
		Encapsulation e = new Encapsulation();
		e.setName("Naga");
		e.setAge(23);
		System.out.println(e.getName());
		System.out.println(e.getAge());
	}
}
