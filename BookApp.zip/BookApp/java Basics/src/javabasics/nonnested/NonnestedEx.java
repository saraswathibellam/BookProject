package javabasics.nonnested;

class Outer {
	void print() {
		System.out.println("This is outer");
	}
}

public class NonnestedEx {
	void printable() {
		System.out.println("This is non-Nested");
	}

	public static void main(String[] args) {

		NonnestedEx n = new NonnestedEx();
		Outer o = new Outer();
		n.printable();
		o.print();

	}

}
