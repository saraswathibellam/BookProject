
public class LoopDoWhile extends LoopingStatements {

	public static void main(String[] args) {
		// Do while loop
		int i=0;
		do {
		System.out.println("The num is :"+i);	
		i++;
		}while(i<=3);

	}

}
