
public class AssignmentOperator {

	public static void main(String[] args) {
		int a;
		System.out.println(a=2); //2
		System.out.println(a+=1); //3
		System.out.println(a-=1); //2
		System.out.println(a*=1); //2
		System.out.println(a/=1); //2
		System.out.println(a&=1); //0
		System.out.println(a^=1); //1
		System.out.println(a|=1); //1
		System.out.println(a<<=1); //2
		System.out.println(a>>=1); //1
		System.out.println(a>>>=1); //0

	}

}
