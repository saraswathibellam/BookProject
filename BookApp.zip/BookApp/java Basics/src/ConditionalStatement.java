
public class ConditionalStatement {

	public static void main(String[] args) {
		//if else if else statement
		int a=0;
		if(a>0)
		{
			System.out.println("It is a positive num :");
		}
		else if(a==0)
		{
			System.out.println("It is neutral num :");
		}
		else
		{
			System.out.println("It is negative num :");
		}
		System.out.println("Hai");
		
	}

}
