
public class Variables {

	public static void main(String[] args) {
		// implicit conversion
		int a=23;
		float b=8;
		float f=33.5f;
		boolean c=true;
		String d="Saru";
		char e='B';
		// explicit conversion
		int g=(int)33.5;
		
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(g);
	
	
	}

}
