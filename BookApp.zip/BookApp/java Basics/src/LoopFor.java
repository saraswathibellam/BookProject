
public class LoopFor extends LoopingStatements {

	public static void main(String[] args) {
		//for loop
		int i=0;
		int sum=0;
		for(i=1;i<=5;i++) {
			sum=i+sum;
			System.out.println("sum of iteration num is :"+sum);		
		}
		System.out.println("sum of first 5 num is :"+sum);

	}

}
