
public class ArithmeticOperators {

	public static void main(String[] args) {
		
		//arithmetic operators
		// +, -, *, /, %
		int a=14,b=5;
		System.out.println("Addition : "+(a+b)); //9
		System.out.println("Subtraction : "+(a-b)); //9
		System.out.println("Multiplication : "+(a*b)); //70
		System.out.println("Division : "+(a/b)); //2
		System.out.println("Modulus : "+(a%b)); //4

	}

}
