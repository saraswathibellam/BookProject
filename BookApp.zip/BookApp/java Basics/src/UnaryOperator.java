
public class UnaryOperator {

	public static void main(String[] args) {
		
	int a=3,b=6,d=7;
	boolean c=false;
		System.out.println("Unary Plus : "+a);//3
		//Increment
		System.out.println("Unary Postfix Inc: "+(a++));//3
		System.out.println("Unary Prefix Inc: "+(++a));//5
		System.out.println("Unary Plus : "+(-b));//-6
		//Decrement
		System.out.println("Unary Postfix  Dec: "+ (b--));//6
		System.out.println("Unary Prefix Dec: "+ (--b));//4
		//not operator 
		System.out.println("Unary Not : " + (!c));//true
		//compliment
		System.out.println("Unary compliment : "+(~d));//-8
		

	}

}
