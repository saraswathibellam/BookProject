
public class RelationalOperator {

	public static void main(String[] args) {
		int a=6, b=3;
		
		System.out.println(a==b); //false
		System.out.println(a!=b); //true
		System.out.println(a<b); //false
		System.out.println(a>b); //true
		System.out.println(a<=b); //false
		System.out.println(a>=b); //true
		

	}

}
