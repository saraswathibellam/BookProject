
public class ShiftOperator {

	public static void main(String[] args) {
		int a=3,b=2,c=-4;
		//left shift
		System.out.println("Left shift +ve : "+(a<<2));//0011 -1100 =12
		System.out.println("Left Shift -ve: "+(c<<1)); 
		//00100 - (11011+1) -11100 - 111000 =-8
		//right shift
		System.out.println("Right Shift +ve: "+(a>>2)); //0011 - 0001 =0
		System.out.println("Right Shift -ve: "+(b>>>1)); // 0010 - 0001 =1
		System.out.println("Right Shift -ve : "+(c>>2));
		//00100 (11011+1) -11110 - 00111 =-1
	
	}

}
