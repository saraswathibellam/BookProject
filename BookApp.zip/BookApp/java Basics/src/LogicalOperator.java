
public class LogicalOperator {

	public static void main(String[] args) {
		int a=2, b=6, c=3;
		System.out.println(a>b&&a<c); //f t =f
		System.out.println(a>b||a>c); //f f =f
		System.out.println(a<b&&a<c); //t t =t
		System.out.println(a>b||a<c); //f t =t

	}

}
