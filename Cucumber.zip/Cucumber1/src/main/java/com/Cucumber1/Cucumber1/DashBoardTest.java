package com.Cucumber1.Cucumber1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.*;

public class DashBoardTest {
	WebDriver driver;
	@Before
	public void setup() {
		System.out.println("===Browser launched & setup done");
	}
	
	@After
	public void teardown() {
		System.out.println("===Browser closed & cleanup done");
	}
	
	@BeforeStep
	public void beforestep() {
		System.out.println("->About to execute a step");
	}
	
	@AfterStep
	public void afterStep() {
		System.out.println("<-Finished execting a step");
	}
	
	@Given("Naviagate to Dashboard")
	public void naviagate_to_dashboard() {
	    driver =new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.get("https://www.saucedemo.com");
	    driver.findElement(By.id("user-name")).sendKeys("standard_user");
	    driver.findElement(By.id("password")).sendKeys("secret_sauce");
	    driver.findElement(By.id("login-button")).click();
	}

	@When("I click on Add to cart for sauce backback")
	public void i_click_on_add_to_cart_for_sauce_backback() {
	    driver.findElement(By.id("btn_primary btn_inventory")).click();
	}

	@Then("Product should be added to cart")
	public void product_should_be_added_to_cart() {
	    String prd = driver.findElement(By.className("inventory_item_name")).getText();
	    Assert.assertEquals("Sauce Labs Backpack",prd);
	    driver.quit();
	}
	@Then("User should be logged in")
	public void user_should_be_logged_in() {
	    System.out.println("login");
	}

	@Given("User is on login page")
	public void user_is_on_login_page() {
		driver =new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.get("https://www.saucedemo.com");
	}

	@When("User enters {string} and {string}")
	public void user_enters_and(String string, String string2) {
		driver.findElement(By.id("user-name")).sendKeys(string);
	    driver.findElement(By.id("password")).sendKeys(string);
	    driver.findElement(By.id("login-button")).click();
	    driver.quit();
	}

	


}
