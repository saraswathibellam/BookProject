package com.Cucumber1.Cucumber1;

import org.openqa.selenium.By;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.Assert;



import io.cucumber.java.en.*;

public class LoginTester {
	
	WebDriver driver;
	
	
	@Given("Iam on the login page")
	public void iam_on_the_login_page() {
		driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.saucedemo.com");
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
	}

	@When("I enter my username and password")
	public void i_enter_my_username_and_password() {
		 driver.findElement(By.id("user-name")).sendKeys("standard_user");
		    driver.findElement(By.id("password")).sendKeys("secret_sauce");
	}

	@When("I click the login button")
	public void i_click_the_login_button() {
	    driver.findElement(By.id("login-button")).click();
	    
	}

	@Then("I should be navigated to the home page")
	public void i_should_be_navigated_to_the_home_page() {
	    String prdname=driver.findElement(By.xpath("//div[.='Sauce Labs Backpack']")).getText();
	    Assert.assertEquals("Sauce Labs Backpack", prdname);
	    driver.quit();
	}

	@When("I enter my invalid username and password")
	public void i_enter_my_invalid_username_and_password() {
		 driver.findElement(By.id("user-name")).sendKeys("user");
		    driver.findElement(By.id("password")).sendKeys("sauce");
	}
	@Then("error message should be displayed")
	public void error_message_should_be_displayed() {
	    String error = driver.findElement(By.xpath("//h3[@data-test='error']")).getText();
	    Assert.assertEquals("Epic sadface: Username and password do not match any user in this service",error);
	    driver.quit();
	}


}
